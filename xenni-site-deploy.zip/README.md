# XENNI 齊間 — static site

Plain HTML. No build step, no dependencies.

- `index.html` is the home page; every other page is a sibling file
  (`seasonal.html`, `carry.html`, `masters.html`, `teacher-jian.html`, …).
- All images are embedded in the pages, so the folder is self-contained.
- `vercel.json` turns on clean URLs, so the pages are served at
  `/seasonal`, `/carry`, `/masters` … and the `.html` addresses redirect there.

## Deploying on Vercel

Either upload this whole folder to the GitHub repo the Vercel project watches
(GitHub → Add file → Upload files → drag everything in → Commit), or create a
new Vercel project pointed at a repo containing these files. Vercel needs no
framework preset: choose "Other" and leave the build command empty.
